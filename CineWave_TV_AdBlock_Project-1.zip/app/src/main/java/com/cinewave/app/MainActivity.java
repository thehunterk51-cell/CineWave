package com.cinewave.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.net.URI;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private static final String MOVIES_URL = "https://azmovies.to/";
    private static final String SERIES_URL = "https://noxx.gg/";
    private static final String PREFS = "cinewave_settings";
    private static final String PREF_ADBLOCK = "ad_block_enabled";

    private LinearLayout root;
    private WebView webView;
    private boolean adBlockEnabled = true;
    private Button adBlockButton;

    // Basic in-WebView blocklist. This is not a complete ad blocker.
    private static final Set<String> AD_HOSTS = new HashSet<>(Arrays.asList(
        "doubleclick.net",
        "googlesyndication.com",
        "googleadservices.com",
        "adservice.google.com",
        "adnxs.com",
        "adsrvr.org",
        "advertising.com",
        "criteo.com",
        "taboola.com",
        "outbrain.com",
        "popads.net",
        "popcash.net",
        "propellerads.com",
        "exoclick.com",
        "trafficjunky.net",
        "juicyads.com",
        "adsterra.com",
        "hilltopads.net"
    ));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        adBlockEnabled = prefs.getBoolean(PREF_ADBLOCK, true);
        showHome();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setFocusable(false);
        return t;
    }

    private Button makeButton(String label, int color) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setFocusable(true);
        b.setFocusableInTouchMode(true);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        return b;
    }

    private LinearLayout newRoot() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        layout.setPadding(dp(22), dp(20), dp(22), dp(20));
        layout.setBackgroundColor(Color.rgb(15, 17, 29));
        layout.setFocusableInTouchMode(true);
        return layout;
    }

    private void toggleAdBlock() {
        adBlockEnabled = !adBlockEnabled;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putBoolean(PREF_ADBLOCK, adBlockEnabled).apply();
        updateAdBlockButton();
        Toast.makeText(this, adBlockEnabled
            ? "حجب الإعلانات مفعّل"
            : "حجب الإعلانات متوقف", Toast.LENGTH_SHORT).show();
        if (webView != null) webView.reload();
    }

    private void updateAdBlockButton() {
        if (adBlockButton != null) {
            adBlockButton.setText(adBlockEnabled
                ? "حجب الإعلانات: مفعّل ✓"
                : "حجب الإعلانات: متوقف");
        }
    }

    private void showHome() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }

        root = newRoot();

        TextView logo = text("🎬  CineWave", 30, Color.WHITE);
        logo.setTypeface(null, 1);
        root.addView(logo, new LinearLayout.LayoutParams(-1, dp(70)));

        TextView subtitle = text("الأفلام والمسلسلات في مكان واحد", 17, Color.rgb(190, 195, 215));
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(50)));

        Button movies = makeButton("🎞  الأفلام  •  AZMovies", Color.rgb(103, 58, 183));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(60));
        bp.setMargins(0, dp(12), 0, dp(10));
        root.addView(movies, bp);
        movies.setOnClickListener(v -> openSite("الأفلام", MOVIES_URL));

        Button series = makeButton("📺  المسلسلات  •  NOXX", Color.rgb(0, 119, 145));
        root.addView(series, new LinearLayout.LayoutParams(-1, dp(60)));
        series.setOnClickListener(v -> openSite("المسلسلات", SERIES_URL));

        adBlockButton = makeButton("", Color.rgb(54, 60, 80));
        LinearLayout.LayoutParams adp = new LinearLayout.LayoutParams(-1, dp(56));
        adp.setMargins(0, dp(16), 0, dp(8));
        root.addView(adBlockButton, adp);
        updateAdBlockButton();
        adBlockButton.setOnClickListener(v -> toggleAdBlock());

        Button saved = makeButton("☆  المشاهدة لاحقًا", Color.rgb(54, 60, 80));
        root.addView(saved, new LinearLayout.LayoutParams(-1, dp(56)));
        saved.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("المشاهدة لاحقًا")
            .setMessage("القائمة المحفوظة ستُضاف في مرحلة لاحقة. يمكننا حفظ روابط الصفحات، أما تنزيل الفيديو فيتطلب أن يتيحه الموقع وأن يكون مسموحًا به.")
            .setPositiveButton("حسنًا", null).show());

        TextView note = text("متوافق مبدئيًا مع الهاتف وAndroid TV / TV Box. بعض المواقع قد لا تدعم WebView أو التحكم بالريموت بشكل كامل.", 13, Color.rgb(160, 165, 185));
        note.setPadding(dp(4), dp(14), dp(4), dp(4));
        root.addView(note, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
        root.requestFocus();
    }

    private void openSite(String title, String url) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(15, 17, 29));

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(8), dp(4), dp(8), dp(4));

        Button back = makeButton("رجوع", Color.rgb(54, 60, 80));
        toolbar.addView(back, new LinearLayout.LayoutParams(dp(82), dp(46)));
        back.setOnClickListener(v -> showHome());

        TextView pageTitle = text(title, 17, Color.WHITE);
        pageTitle.setTypeface(null, 1);
        toolbar.addView(pageTitle, new LinearLayout.LayoutParams(0, dp(46), 1));

        Button block = makeButton(adBlockEnabled ? "حجب ✓" : "حجب ✕", Color.rgb(103, 58, 183));
        toolbar.addView(block, new LinearLayout.LayoutParams(dp(88), dp(46)));
        block.setOnClickListener(v -> {
            toggleAdBlock();
            block.setText(adBlockEnabled ? "حجب ✓" : "حجب ✕");
        });

        root.addView(toolbar, new LinearLayout.LayoutParams(-1, dp(56)));

        webView = new WebView(this);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                return scheme != null && !(scheme.equals("http") || scheme.equals("https"));
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (adBlockEnabled && isBlockedAdUrl(request.getUrl().toString())) {
                    return new WebResourceResponse(
                        "text/plain", "UTF-8",
                        new ByteArrayInputStream(new byte[0])
                    );
                }
                return super.shouldInterceptRequest(view, request);
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        webView.loadUrl(url);
        webView.requestFocus();
    }

    private boolean isBlockedAdUrl(String url) {
        try {
            URI uri = URI.create(url);
            String host = uri.getHost();
            if (host == null) return false;
            host = host.toLowerCase();
            for (String blocked : AD_HOSTS) {
                if (host.equals(blocked) || host.endsWith("." + blocked)) return true;
            }
        } catch (Exception ignored) {
            return false;
        }
        return false;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            showHome();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
